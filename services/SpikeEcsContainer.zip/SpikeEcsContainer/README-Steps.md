# How to: Provision a CloudFormation ECS Stack and run containers from an ECR container repo

1. Create a Task Definition
   This defines:
    - Which Docker images to use with the containers in your task
    - How much CPU and memory to use with each container
    - Whether containers are linked together in a task
    - The Docker networking mode to use for the containers in your task
    - What (if any) ports from the container are mapped to the host container instance
    - Whether the task should continue to run if the container finishes or fails
    - The command the container should run when it is started
    - What (if any) environment variables should be passed to the container when it starts
    - Any data volumes that should be used with the containers in the task
    - What (if any) IAM role your tasks should use for permissions

A [Service scheduler](http://docs.aws.amazon.com/AmazonECS/latest/developerguide/scheduling_tasks.html) is responsible for maintaining running tasks
[Task Placement](http://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-placement.html) - Is the way for ECS to figure out where to place the task:
- Using a task placement strategy
- Honouring task placement constraints: e.g. number of instances of task per host, or use an expression to determine if an instance is suitable for running a task

2. Create a Service
    Defines a specified number of instances of a task definition to run and maintain in an ECS Cluster. A service can be:
    - Load balanced
    - Auto scaled
    - Updated
    - Deleted
    
    The deployment configuration of a service determines the deployment strategy used by ECS if the min healthy percent is less than 100, service scheduler tries to bring down service instances and deploy updates

Updating a service [docs](http://docs.aws.amazon.com/AmazonECS/latest/developerguide/update-service.html)
A service packages a task definition

Difference in how a Task is considered healthy:
- No Load Balancer:
  considered healthy if they are in the RUNNING state; 
- With Load Balancer:
  tasks for services that do use a load balancer are considered healthy if they are in the RUNNING state and the container instance it is hosted on is reported as healthy by the load balancer. 
  
  The default value for minimum healthy percent is 50% in the console and 100% for the AWS CLI, the AWS SDKs, and the APIs.

Example:
    Number of ECS instances = 4
    Min Healthy Percent     = 50%
    Max Healthy Percent     = 100%
    One task per instance
When updating the service, the scheduler will kill 2 tasks to free up cluster capacity before deploying new tasks 

2.1 Steps to update a service {ref: To update a running service [here](http://docs.aws.amazon.com/AmazonECS/latest/developerguide/update-service.html)}
- Select region where the cluster resides
- select cluster name
- Navigate to the service
- Change task definition - new image / deployment config / number of tasks OR any combination of these
- Choose update

```bash
aws cloudformation --update-stack 
```

## Approach
1. Create Stack Initially: 

```bash 
aws cloudformation --create-stack 
```

2. Update Stack
The passed template will update the task definition
This should trigger the service to recognise that the task has changed and trigger a redeployment using the deployment strategy