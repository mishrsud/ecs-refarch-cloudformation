param
(
    [Parameter(Mandatory=$true)]
    [string] $ImageTag,
    [Parameter(Mandatory=$false)]
    [string] $EcrRepoUri="470402704369.dkr.ecr.ap-southeast-2.amazonaws.com/bsl-docker-test"
)

$DefaultRegion = "ap-southeast-2"

Write-Verbose "Logging in to AWS $DefaultRegion"
$loginCommand = aws ecr get-login --region $DefaultRegion
Invoke-Expression $loginCommand

Write-Verbose "Publishing code"
dotnet publish $PSScriptRoot/../BSL_Docker_Test.sln -c Release -o ./obj/Docker/publish

Write-Verbose "Initiating docker build"
docker build -t bsl-docker-test $PSScriptRoot/../BSL_Docker_Test

Write-Verbose "Tagging docker image as ${EcrRepoUri}:$ImageTag"
docker tag bsl-docker-test:latest ${EcrRepoUri}:$ImageTag

Write-Verbose "Pushing image to ECR"
docker push ${EcrRepoUri}:$ImageTag
