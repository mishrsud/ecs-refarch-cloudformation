﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace BSL_Docker_Test.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        // GET api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            var frameworkDescription = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription;
            var osArchitecture = System.Runtime.InteropServices.RuntimeInformation.OSArchitecture;
            var processArchitecture = System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture;
            var osNameAndVersion = System.Runtime.InteropServices.RuntimeInformation.OSDescription;
            var apiVersion = "1.9";

            return new string[] { apiVersion, frameworkDescription, osArchitecture.ToString(), processArchitecture.ToString(), osNameAndVersion, "value2b" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
