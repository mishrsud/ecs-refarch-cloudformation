param
(
    [Parameter(Mandatory=$true)]
    [string] $NameOfContainer,  
    [Parameter(Mandatory=$false)]
    [string] $NameOfImage,     
    [Parameter(Mandatory=$false)]
    [switch] $RemoveImage
)

#$NameOfContainer = "BSL_Docker_Test"
#$dockerContainers = (docker ps -f name=$NameOfContainer --no-trunc) | Out-String
#write-host $dockerContainers

# Stop the container
docker stop $NameOfContainer

if ($RemoveImage){
    # Delete the current container
    docker rm $NameOfContainer

    # Remove the image
    docker rmi $NameOfImage
}