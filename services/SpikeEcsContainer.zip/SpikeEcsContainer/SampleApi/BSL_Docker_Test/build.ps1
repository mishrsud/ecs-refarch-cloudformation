$env:DOCKER_BUILD_SOURCE = "obj/Docker/empty/";
docker-compose -f "C:\dev\temp\BSL_Docker_Test\docker-compose.yml" -f "C:\dev\temp\BSL_Docker_Test\docker-compose.override.yml" -f "C:\dev\temp\BSL_Docker_Test\docker-compose.vs.debug.yml" -p dockercompose540629272 config
docker  ps --filter "status=running" --filter "name=dockercompose540629272_bsl_docker_test_" --format {{.ID}} -n 1
docker  exec -i 9de0f47f6109 /bin/bash -c "if PID=$(pidof -x dotnet); then kill $PID; fi"
C:\windows\System32\WindowsPowerShell\v1.0\powershell.exe -NonInteractive -NoProfile -WindowStyle Hidden -ExecutionPolicy RemoteSigned -File "C:\Users\clayteo\AppData\Local\Temp\GetVsDbg.ps1" -Version vs2017u1 -RuntimeID debian.8-x64 -InstallPath "C:\Users\clayteo\clrdbg\vsdbg"
docker-compose -f "C:\dev\temp\BSL_Docker_Test\docker-compose.yml" -f "C:\dev\temp\BSL_Docker_Test\docker-compose.override.yml" -f "C:\dev\temp\BSL_Docker_Test\docker-compose.vs.debug.yml" -p dockercompose540629272 up -d