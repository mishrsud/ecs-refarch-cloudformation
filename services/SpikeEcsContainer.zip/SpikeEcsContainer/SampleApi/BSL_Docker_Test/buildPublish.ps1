#login
$loginCommand = aws ecr get-login --region ap-southeast-2
Invoke-Expression $loginCommand

#build and publish
dotnet publish ../BSL_Docker_Test.sln -c Release -o ./obj/Docker/publish
docker build -t bsl-docker-test .
docker tag bsl-docker-test:latest 470402704369.dkr.ecr.ap-southeast-2.amazonaws.com/bsl-docker-test:latest

# push to ecr
docker push 470402704369.dkr.ecr.ap-southeast-2.amazonaws.com/bsl-docker-test:latest
