param
(
    [Parameter(Mandatory=$true)]
    [string] $StackArn,
    [Parameter(Mandatory=$true)]
    [string] $ChangeSetName,
    [Parameter(Mandatory=$true)]
    [string] $EcrImageName
)


Write-Verbose "Uploading the YAML files to S3"
.\Sync-CloudFormation.ps1 -FolderToSync "../ecs-refarch-cloudformation" -S3Uri "s3://ofx.ols.ecs/night"
Write-Verbose "Finished uploading the YAML files to S3"

Write-Verbose "Creating the change set for stack: $StackArn, and change set name: $ChangeSetName"
aws cloudformation create-change-set --stack-name $StackArn --change-set-name $ChangeSetName --capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM --no-use-previous-template --template-url https://s3-ap-southeast-2.amazonaws.com/ofx.ols.ecs/night/master.yaml --parameters ParameterKey="SSHKey",UsePreviousValue=true ParameterKey="SSHCidr",UsePreviousValue=true ParameterKey=EcrImage,ParameterValue=$EcrImageName
Write-Verbose "Finished creating the change set"

Write-Verbose "Getting the list of change sets for stack: $StackArn"
$changeSetList = aws cloudformation list-change-sets --stack-name  $StackArn | ConvertFrom-Json
$changeSetArn = $changeSetList.Summaries[0] | Where-Object { $_.ChangeSetName -eq "$ChangeSetName" } | Select-Object -ExpandProperty ChangeSetId
Write-Verbose "Found changed set with ARN: $changeSetArn" 

Write-Verbose "Waiting for change set creation to complete"
Start-Sleep -s 10
Write-Verbose "Executing change set: $changeSetArn"
aws cloudformation execute-change-set --change-set-name $changeSetArn
Write-Verbose "Finished executing change set: $changeSetArn"