<#

.SYNOPSIS
This script will switch features on or off by modifying the .NET config file and will then restart the service for the changes to take effect. 

.EXAMPLE
.\Sync-CloudFormation.ps1 -FolderToSync "./PathToYaml" -S3Uri s3://ofx.ols.ecs/night/services
Where Path = path to the bin folder where service binaries are deployed

.INPUTS:
-FolderToSync      : The relative path to the folder containing CloudFormation Yaml files to sync to the specified S3 bucket
-S3Uri             : A URI to the S3 bucket to upload to

#requires -version 3.0
#requires -aws cli
#>

# 
param
(
    [Parameter(Mandatory=$true)]
    [string] $FolderToSync,
    [Parameter(Mandatory=$true)]
    [string] $S3Uri
)

aws s3 cp $FolderToSync $S3Uri --recursive --exclude "*" --include "*.yaml"