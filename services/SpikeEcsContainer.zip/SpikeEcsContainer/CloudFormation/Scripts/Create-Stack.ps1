param
(
    [Parameter(Mandatory=$true)]
    [string] $StackName,
    [Parameter(Mandatory=$true)]
    [string] $SshKeyName,
    [Parameter(Mandatory=$true)]
    [string] $EcrImageName,
    [Parameter(Mandatory=$false)]
    [string] $SshCidr = "202.139.114.161/0"
)

aws cloudformation create-stack  --stack-name $StackName --capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM --template-url https://s3-ap-southeast-2.amazonaws.com/ofx.ols.ecs/night/master.yaml --parameters  ParameterKey=SSHKey,ParameterValue=$SshKeyName ParameterKey=SSHCidr,ParameterValue=$SshCidr ParameterKey=EcrImage,ParameterValue=$EcrImageName
