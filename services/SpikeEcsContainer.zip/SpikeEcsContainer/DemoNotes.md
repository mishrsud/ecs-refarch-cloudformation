# Resources

- StackArn: arn:aws:cloudformation:ap-southeast-2:470402704369:stack/EcsSpikeDemo/4ce650c0-3f52-11e7-a0b6-50fae94fac82
- EcrImage: 470402704369.dkr.ecr.ap-southeast-2.amazonaws.com/bsl-docker-test:1.<Insert-revision-here>
- ALB Public DNS: http://ecsspikedemo-1024356229.ap-southeast-2.elb.amazonaws.com/api/values


## Walk through of solution structure

1. CloudFormation: Contains CloudFormation templates following AWS [Reference architecture for ECS](https://github.com/awslabs/ecs-refarch-cloudformation)
    - CloudFormation/Scripts: PowerShell scripts to automate the create, update and delete stages of a stack
        - Create-Stack.ps1: Creates a new stack and deploys images on it
            - Create-Stack.ps1 [-StackName] "Unique name for stack" [-SshKeyName] "SSH key name" [-EcrImageName] "ECR repo uri:tag" [[-SshCidr] "public ip to be allowed for SSH"]
        - Create-ChangeSet.ps1: Creates and executes an update
            - Create-ChangeSet.ps1 [-StackArn] "ARN of the Stack" [-ChangeSetName] "Unique, descriptive name of change set" [-EcrImageName] "ecr repo uri:tag"
        - Sync-CloudFormation.ps1: Syncs updated templates to S3 for AWS to read from. Called from Create-ChangeSet.ps1
        - Delete-Stack.ps1: Tears down a stack
2. SampleApi: Contains a basic dotnetcore Web API used as the service to deploy on an ECS Cluster using the reference architecture templates
    - SampleApi/Scripts: PowerShell scripts to automate the development lifecycle of a docker image 
        - Create-DockerImage.ps1: Build a docker image from source code and push to ECR
        - Cleanup-LocalDev.ps1: Cleanup locally running containers
        - build.ps1: docker-compose multiple services as containers

## Proposed CI/CD story

1. The CI Server builds the docker image that is going to be deployed to an ECS cluster
2. The CD stage uses CloudFormation to deploy to the ECS cluster

## Demo Walk-through:
1. Create Stack - Already provisioned ahead of time as creation takes ~ 10 - 15 minutes
2. Update Stack 
    - Update code
    - Build and push the docker image to ECR
    - Initiate the creation of a change set, execute the change set
    - Once update completes, hit the API